

$("#asigna").click(function(){
var numProyecto = $("#numProyecto").val();
var estado = $("#estado").val();
var nombreEstudiante = $("#nombreEstudiante").val();
var idEstudiante = $("#idEstudiante").val();
var ruta = "http://www.psp7.com/Tareas";

$.ajax({
	url: ruta,
	type: 'POST',
	dataType: 'json',
	data: {asigna: numProyecto, estado, 
			nombreEstudiante,idEstudiante}
});
});
